## Instructions
1. Extract all files to a folder
2. Download and install python from https://www.python.org/downloads/
2. Install all required libraries on command prompt (`pip install -r packages.txt`)
4. Take similar screenshots to those in the folder /images and replace them. Those are set up for 2K monitors at Punika fishing spot, might work for else where, might not idk.
5. Change parameters in configuration.yaml if needed
4. Run the bot (main.py)
